package com.example.appdeporte;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppDeporteApplicationTests {

    @Test
    void contextLoads() {
    }

}
