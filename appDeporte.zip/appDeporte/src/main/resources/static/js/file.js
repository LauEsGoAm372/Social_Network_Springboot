function sendfile() {
    var inputFile = $('#fileInput')[0].files[0];
    var formData = new FormData();
    formData.append('archivo', inputFile);

    $.ajax({
        url: '/api/file/subir',
        type: 'POST',
        data: formData,
        contentType: false,
        processData: false,
        success: function(data) {
            console.log('Archivo subido con éxito');
        },
        error: function(xhr, status, error) {
            console.error('Error al subir el archivo');
        }
    });
}

function getfile(nombrearchivo){
    var nombreArchivo = "nombrearchivo"; // Nombre del archivo a mostrar

    fetch("/api/file/bajar/" + nombreArchivo)
        .then(response => {
            if (response.ok) {
                return response.blob();
            } else {
                throw new Error("Error al mostrar el archivo");
            }
        })
        .then(blob => {
            // Crear una URL temporal para el archivo
            var fileURL = URL.createObjectURL(blob);

            // Abrir el archivo en una nueva ventana o pestaña del navegador
            window.open(fileURL);
        })
        .catch(error => {
            console.error("Error en la solicitud AJAX:", error);
        });

}
