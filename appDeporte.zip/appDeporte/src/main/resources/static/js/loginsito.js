function red(){
    window.location.replace("/registrar.html")
}
function sendauth(){
    let data={
        email:$("#email").val(),
        password:$("#password").val()
    }
    $.ajax({
        url:"api/auth/authenticate",
        type:"POST",
        contentType:'application/json; charset=utf-8',
        dataType:"json",
        data:JSON.stringify(data),

        success: function(datar) {
            alert(data);
            $("#email").val("");
            $("#password").val("");
            Cookies.set('token', datar.token);
            window.location.replace("/inicio.html");
        },
        error: function(xhr, status) {
            console.log("ha sucedido un error");
            console.log("Usuario o contraseña incorrectos");
        }
    });
}
