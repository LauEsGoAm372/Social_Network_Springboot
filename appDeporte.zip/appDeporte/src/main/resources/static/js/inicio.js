function cerrarsesion(){
    Cookies.remove("token");
    window.location.replace("/login2.html")
}
function getOneData() {
    let pass = Cookies.get('token');
    console.log(pass);
    $.ajax({
        headers:{
            'Authorization':'Bearer '+pass
        },
        url: 'api/user/getone/blablabla',
        type: 'GET',
        dataType: 'json',
        contentType: 'application/json; charset=utf-8',
        success: function(data) {
            showOnelement(data);
        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.log("Ha sucedido un error");
        }
    });
}

function showOnelement(element) {
    let daticos = `
    <p> ${element.firstname} </p>
  `;
    $("#nombre").html(daticos);
}

function parseJwt(token) {
    const base64Url = token.split('.')[1];
    const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    const jsonPayload = decodeURIComponent(
        atob(base64)
            .split('')
            .map(function (c) {
                return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
            })
            .join('')
    );
    return JSON.parse(jsonPayload);
}