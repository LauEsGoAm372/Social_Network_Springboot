/**
 *
 */
function sendData(){
    let data={
        firstname:$("#firstname").val(),
        lastname:$("#lastname").val(),
        email:$("#email").val(),
        sport:$("#sport").val(),
        age:$("#age").val(),
        height:$("#height").val(),
        weight:$("#weight").val(),
        cellphone:$("#cellphone").val(),
        password:$("#password").val(),
        image:$("#image").val()
    }
    $.ajax({
        url:"api/auth/register",
        type:"POST",
        contentType:'application/json; charset=utf-8',
        dataType:"json",
        data:JSON.stringify(data),

        success: function(datar) {
            $("#firstname").val(""),
                $("#lastname").val(""),
                $("#email").val(""),
                $("#sport").val(""),
                $("#age").val(""),
                $("#height").val(""),
                $("#weight").val(""),
                $("#cellphone").val(""),
                $("#password").val(""),
                $("#image").val("")
            Cookies.set('token', datar.token);
            window.location.replace("/inicio.html");
            },
        error: function(xhr, status) {
            console.log("ha sucedido un error");
            alert("Todos los campos son obligatorios");

        },
        complete: function(xhr, status) {
            alert("Proceso exitoso");
        }

    });
}