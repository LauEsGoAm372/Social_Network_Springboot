package com.example.appdeporte.user;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
@Repository
public class UserRepository {
    @Autowired
    private UserCrudRepository userCrudRepository;

    public Optional<User> findByEmail(String email){
        return userCrudRepository.findByEmail(email);
    }
    public User save(User u){
        return userCrudRepository.save(u);
    }

    public Optional<User> findByPassword(String password){
        return userCrudRepository.findByPassword(password);
    }

}
