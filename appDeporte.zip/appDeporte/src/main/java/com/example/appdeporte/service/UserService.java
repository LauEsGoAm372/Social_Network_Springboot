package com.example.appdeporte.service;

import com.example.appdeporte.user.User;
import com.example.appdeporte.user.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserService {
    @Autowired
    private UserRepository  userRepository;

    public User save(User u){
        return userRepository.save(u);
    }
    public Optional<User> getone(String password){
        Optional<User> objetito = userRepository.findByPassword(password);
        if (objetito.isPresent()) {
             objetito.get();
        }else{
             System.out.println("No existe");
        }
        return objetito;
    }
}
