package com.example.appdeporte;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppDeporteApplication {

    public static void main(String[] args) {
        SpringApplication.run(AppDeporteApplication.class, args);
    }

}
