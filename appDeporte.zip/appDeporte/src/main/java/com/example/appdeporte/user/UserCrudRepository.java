package com.example.appdeporte.user;

import org.springframework.data.repository.CrudRepository;

import java.util.Optional;

public interface UserCrudRepository extends CrudRepository<User,Long>{
    Optional<User> findByEmail(String email);

    Optional<User> findByPassword(String password);

    // Optional<User> findByName(String name);

}
