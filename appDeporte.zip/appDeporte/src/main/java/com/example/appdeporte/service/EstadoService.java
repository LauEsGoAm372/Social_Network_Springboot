package com.example.appdeporte.service;

public class EstadoService {
}
