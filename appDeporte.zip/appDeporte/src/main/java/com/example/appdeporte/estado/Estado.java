package com.example.appdeporte.estado;

import com.example.appdeporte.user.User;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Estado {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id_estado;
    private String estado;
    private String contenido;
    private String comentario;
    @ManyToOne
    @JoinColumn(name = "id_user")
    @JsonIgnoreProperties({"estado"})
    private User user;
}
